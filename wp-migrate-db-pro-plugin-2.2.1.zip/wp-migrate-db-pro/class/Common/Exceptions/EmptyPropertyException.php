<?php
namespace DeliciousBrains\WPMDB\Common\Exceptions;

class EmptyPropertyException extends \RuntimeException {}
